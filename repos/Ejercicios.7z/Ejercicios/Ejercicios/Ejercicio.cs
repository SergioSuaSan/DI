﻿using System.Security.Cryptography.X509Certificates;

namespace Ejercicios.Ejercicios
{
    public abstract class Ejercicio
    {
        public abstract void ejecutar();
        
    }
}