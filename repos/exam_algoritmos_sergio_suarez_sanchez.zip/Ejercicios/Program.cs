﻿// See https://aka.ms/new-console-template for more information


using System;
using System.Text;


namespace Ejercicios
{
    class Programa
    {

        static void Main(string[] args)
        {

            Menu menu = new Menu();
            menu.ejercicio10();

        }

    }
    
}
