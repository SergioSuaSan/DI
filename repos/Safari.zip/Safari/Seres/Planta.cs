﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safari.Seres
{
    internal class Planta : Ser
    {
        public Planta(int i, int j) : base(i, j) { }




        public override void morir()
        {
            
        }

        public override void reproduccion()
        {
            

        

        }


     
    }
}
