﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Safari.Seres
{
    internal abstract class Hervivoro : Animal
    {
        public Hervivoro(int fila, int colum) : base(fila, colum) { }
    }
}
